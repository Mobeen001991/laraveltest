<?php

namespace App\Http\Controllers;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Mail;
use App\Models\User;
class AdminController extends Controller
{
    public function sendRegisterMail(Request $request)
    {

        $this->validate($request, [
            'email' => 'required|email',

        ]);
        Mail::send('invite', [], function ($message) use ($request) {
            $message->to($request->email, $request->email)->subject
                ('Invitation');
        });

        return response()->json([
            'success' => true,
            'data' => $request,
        ]);
    }
}
