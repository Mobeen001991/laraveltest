<div>

<p> This is your 6 digit pin: {{$pin}} </p>

</div>

