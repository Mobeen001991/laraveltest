<div>
Please click on link to Register <a href="example.com">example.com</a>

</div>