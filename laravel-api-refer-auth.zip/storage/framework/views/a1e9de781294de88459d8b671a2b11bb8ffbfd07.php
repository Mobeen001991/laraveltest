<div>

<p> This is your 6 digit pin: <?php echo e($pin); ?> </p>

</div>

<?php /**PATH H:\xampp\htdocs\laravel\laravel-api-refer-auth\resources\views/confirm.blade.php ENDPATH**/ ?>